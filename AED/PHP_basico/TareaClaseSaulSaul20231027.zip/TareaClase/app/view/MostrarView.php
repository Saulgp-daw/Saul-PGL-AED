<?php

class MostrarView {
    public function __contruct(){}

    private function cabecera(){
        return '            
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="CSS/estiloCatalogo.css">
            <title>Mostrar Anotaciones</title>
            
        </head>
        <body>';
    }

    private function pie(){
        return '
        </body>
        </html>            
        ';
    }

    public function body($anotaciones){
        echo $this->cabecera();
        echo "<h3 class='titulo'>-Mostrar Anotaciones-</h3>";
        
        foreach ($anotaciones as $anotacion) {
           
            //print_r($anotacion[0]);

            $datos = explode(";",$anotacion[0]);
            //print_r($datos);

            $autor = $datos[0];
            $titulo = $datos[1];
            $contenido = $datos[2];
            $fechaActual = $datos[3];
            $fechaFormateada = date('Y-m-d H:i:s', $fechaActual);

            echo "Autor: ".$autor . "<br>";
            echo "Titulo: ".$titulo . "<br>";
            echo "Contenido: ".$contenido . "<br>";
            echo "FechaActual: ".$fechaFormateada . "<br>";
            echo "<br><br>";
        
        }
        echo "<br>".$this->enlacesPaginas("Volver");
        echo $this->pie();
    }

    private function enlacesPaginas($mensaje){
        return '<a href="../">'. $mensaje .'</a>';
    }


}

?>