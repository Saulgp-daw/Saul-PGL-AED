<?php 
    require_once("app/model/Anotacion.php");
    require_once("app/controller/GestionarFichero.php");

    class TextosController{

        public static $anotaciones;

        function index($args){
            echo "Hola";
        }

        public static function cargarDatos(){
            $gestionarFichero = new GestionarFichero();
            $datos = $gestionarFichero->cargarCSV();
            if ($datos) {
                self::$anotaciones = $datos;
            }
        }

        function crear( $args ){
            require_once("app/view/CrearView.php");
            $vistaCrear = new CrearView();
            $vistaCrear->body();
        }

        function crearAnotacion($args){
            $autor = $args['autor'];
            $titulo = $args['titulo'];
            $contenido = $args['contenido'];
            $unixtime = time();
            $fechaActual = date('Y-m-d H:i:s', $unixtime);
            $anotacion = new Anotacion( $autor, $titulo, $contenido, $unixtime );
            $anotacionAString = ["$anotacion->autor;$anotacion->titulo;$anotacion->contenido;$anotacion->fechaActual"];
            array_push(self::$anotaciones, $anotacionAString);

            $gestionarFichero = new GestionarFichero();
            $gestionarFichero->guardarCSV(self::$anotaciones);

        }

        function mostrar( $args ){
            require_once("app/view/MostrarView.php");
            $vistaMostrar = new MostrarView();
            $vistaMostrar->body(self::$anotaciones);
        }

    }

    TextosController::cargarDatos();
