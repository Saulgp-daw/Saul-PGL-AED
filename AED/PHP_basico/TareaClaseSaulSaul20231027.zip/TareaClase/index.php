<?php

    require_once 'app/Router.php';

    Router::init();
?>