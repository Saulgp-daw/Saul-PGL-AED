<?php
    echo "hola mundo";
?>