<?php

namespace App\Contracts;

class MesaContract {
    public const TABLE_NAME="mesas";
    public const COL_NUMBER="num_mesa";
    public const COL_SEATS="sillas";
}