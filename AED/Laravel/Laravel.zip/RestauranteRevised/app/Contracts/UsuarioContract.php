<?php

namespace App\Contracts;

class UsuarioContract {
    public const TABLE_NAME="usuarios";
    public const COL_TEL="telefono";
    public const COL_NAME="nombre";
    public const COL_PASSWORD="contrasenha";
    public const COL_ROLE="rol";
}