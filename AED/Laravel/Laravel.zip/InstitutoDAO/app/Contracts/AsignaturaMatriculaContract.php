<?php
namespace App\Contracts;

class AsignaturaMatriculaContract{
    public const TABLE_NAME="asignatura_matricula";
    public const COL_ID="id";
    public const COL_IDMATRICULA="idmatricula";
    public const COL_IDASIGNATURA="idasignatura";
}
?>
