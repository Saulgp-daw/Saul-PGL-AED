<?php
namespace App\Contracts;

class UsuarioContract{
    public const TABLE_NAME="usuarios";
    public const COL_NICKNAME="nickname";
    public const COL_PASSWORD="password_hash";
}
?>
