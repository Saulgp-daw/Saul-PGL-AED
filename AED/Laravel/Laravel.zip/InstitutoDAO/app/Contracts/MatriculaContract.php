<?php
namespace App\Contracts;

class MatriculaContract{
    public const TABLE_NAME="matriculas";
    public const COL_ID="id";
    public const COL_DNI="dni";
    public const COL_YEAR="year";
}
?>
